import pandas as pd
from sklearn.ensemble import RandomForestClassifier
from random import seed
from sklearn.svm import SVC
import numpy as np
import pandas as pd
# Classification template
from sklearn.linear_model import LogisticRegression
from sklearn.svm import SVC
from sklearn.naive_bayes import GaussianNB
from sklearn.model_selection import train_test_split
from sklearn.neighbors import KNeighborsClassifier
from sklearn.ensemble import RandomForestClassifier
import xgboost as xgb

dataset = pd.read_csv('train.csv')
nor = dataset.loc[:, dataset.columns != 'label']
normal = (nor-nor.mean())/nor.std()
dataset.loc[:,dataset.columns != 'label'] =  normal

"""一开始写错了，只是提取了两行"""
"""X_train = dataset.iloc[:,[1,12]]"""

X_train = dataset.iloc[:, 1:12]
y_train = dataset.iloc[:,12]

#print(X_train)

svmclass = SVC(kernel='linear',random_state=0)
svmclass.fit(X_train,y_train)

# random = RandomForestClassifier()
# random.fit(X_train, y_train)

dataset1 = pd.read_csv('test.csv')
dataset1 = (dataset1-dataset1.mean())/dataset1.std()

# print(dataset1)
X_test = dataset1.iloc[:, 1:12]
#
#print(X_test)
file_path = 'sample_submission.csv'
# predictions = random.predict(X_test)
predictions = svmclass.predict(X_test)
pre = pd.DataFrame(data=predictions)
print(pre)
pre.to_csv(file_path+''+'.csv', index=False)

"""
Another version i write

#处理NAN值，删除id=39的

# Importing the dataset
dataset = pd.read_csv('train.csv')
X_train = dataset.iloc[:, [1, 11]].values
y_train = dataset.iloc[:, 12].values

# logisticRegr = LogisticRegression()
random = RandomForestClassifier()
#X_train1, X_test, y_train1, y_test = train_test_split(X_train, y_train, test_size=0.2, random_state=0)

dataset1 = pd.read_csv('test.csv')
X_test = dataset1.iloc[:, [1, 11]].values

# KNN = KNeighborsClassifier(n_neighbors = 2, metric = 'minkowski', p = 2)
# KNN.fit(X_train,y_train)
# xgboostmodel = xgb.XGBRegressor(learning_rate = 0.1,
#     n_estimators = 300,
#     max_depth = 7,
#     min_child_weight = 3,
#     subsample = 0.8,
#     colsample_bytree = 0.8,
#     seed = 0)
# xgboostmodel = xgb.XGBClassifier()
# xgboostmodel.fit(X_train,y_train)
# svmclass = SVC(kernel='linear',random_state=0)
# svmclass.fit(X_train,y_train)

# naive = GaussianNB(kernel='linear',random_state=0)
# naive.fit(X_train,y_train)

#X_test = dataset1.iloc[:.[1,11]].values
#y_test
#logisticRegr.fit(X_train, y_train)
random.fit(X_train, y_train)
file_path = 'sample_submission.csv'
#predictions = logisticRegr.predict(X_test)
predictions = random.predict(X_test)
# predictions = svmclass.predict(X_test)
#predictions = xgboostmodel.predict(X_test)
#score = logisticRegr.score(X_test, y_test)
# score = svmclass.score(X_test, y_test)
# print(score)
pre = pd.DataFrame(data=predictions)
print(pre)
pre.to_csv(file_path+''+'.csv', index=False)
# score = logisticRegr.score(X_test, y_test)
# print(score)
#print(predictions)
"""

"""
first edition

import pandas as pd
from sklearn.ensemble import RandomForestClassifier
from random import seed
train = pd.read_csv('train.csv',index_col='id')
test = pd.read_csv('test.csv',index_col='id')
test = (test-test.mean())/test.std()
features = train.loc[:, train.columns != 'label']
features = (features-features.mean())/features.std()
train.loc[:, train.columns != 'label']  = features
X = train.drop('label', axis=1)
y = train['label']

print(X)
print(y)


seed(1024)

model = RandomForestClassifier()

model.fit(X,y)
print(test)

test['label'] = model.predict(test)

#print(test)
pred = test['label']
print(pred)
pred.to_csv('submission.csv')

# dataset = pd.read_csv('train.csv')
# nor = dataset.loc[:, dataset.columns != 'label']
# normal = (nor-nor.mean())/nor.std()
# dataset.loc[:,dataset.columns != 'label'] =  normal
#
# X_train = dataset.iloc[:, [1, 11]].values
# y_train = dataset.iloc[:, 12].values
# random = RandomForestClassifier()
#
# dataset1 = pd.read_csv('test.csv')
# dataset1 = (dataset1-dataset1.mean())/dataset1.std()
#
# # print(dataset1)
# X_test = dataset1.iloc[:, [1, 11]].values
# #
# random.fit(X_train, y_train)
# file_path = 'sample_submission.csv'
# predictions = random.predict(X_test)
# pre = pd.DataFrame(data=predictions)
# print(pre)
# pre.to_csv(file_path+''+'.csv', index=False)
"""